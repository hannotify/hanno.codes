import com.infosupport.kenniscentrum.javaadv.printer.Completed;
import com.infosupport.kenniscentrum.javaadv.printer.OutOfInk;
import com.infosupport.kenniscentrum.javaadv.printer.OutOfPaper;
import com.infosupport.kenniscentrum.javaadv.printer.PrintResult;
import com.infosupport.kenniscentrum.javaadv.printer.Printer;

void main() {
    Printer printer = new Printer("HP LaserJet", 8);

    PrintResult printResult = null;
    try {
        printResult = printer.print(10);
    } catch (IOException e) {
        e.printStackTrace();
    }

    var resultString = switch (printResult) {
        case Completed completed -> "Printed " + completed.numberOfPages() + " pages";
        case OutOfInk outOfInk -> "Out of ink for color " + outOfInk.color();
        case OutOfPaper outOfPaper -> "Out of paper: " + outOfPaper;
    };

    System.out.println(resultString);

    testReflection();
}

private void testReflection() {
    var printerClass = Printer.class;
    for (var field : printerClass.getDeclaredFields()) {
        System.out.println(field.getName());
    }
}