package com.infosupport.kenniscentrum.javaadv;

public class RegEx {
    public static void main(String[] args) {
        var input = "Hello, world!";
        var pattern = "[Bb]rainf\\*\\*k";
        var matches = input.matches(pattern);
        System.out.println(matches);
    }
}
