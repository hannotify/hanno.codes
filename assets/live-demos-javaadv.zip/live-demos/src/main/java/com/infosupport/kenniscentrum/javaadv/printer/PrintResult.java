package com.infosupport.kenniscentrum.javaadv.printer;

public sealed interface PrintResult permits Completed, OutOfInk, OutOfPaper {
}

