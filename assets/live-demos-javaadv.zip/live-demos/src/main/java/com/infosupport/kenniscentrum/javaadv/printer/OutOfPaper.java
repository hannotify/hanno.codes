package com.infosupport.kenniscentrum.javaadv.printer;

import java.util.stream.Collectors;

public record OutOfPaper() implements PrintResult {
    @Override
    public String toString() {

        // Pre Java 9:
//        StackTraceElement[] stacktrace = Thread.currentThreÏstad().getStackTrace();
//
//        for (StackTraceElement e : stacktrace) {
//            System.out.println(e);
//        }

        // Java 9+
        StackWalker.getInstance().walk(
                sf -> sf.filter(s -> s.getMethodName().contains("main")).toList()).forEach(System.out::println);

        StackWalker.getInstance()
                .walk(s -> s.skip(2).limit(3)
                        .toList())
                .forEach(System.out::println);

        StackWalker.getInstance()
                .walk(s -> s.limit(10)
                        .filter(f -> f.getClassName().contains("com.example"))
                        .toList())
                .forEach(System.out::println);
        return "OutOfPaper{}";
    }
}
