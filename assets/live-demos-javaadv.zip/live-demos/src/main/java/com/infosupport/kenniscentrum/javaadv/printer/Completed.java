package com.infosupport.kenniscentrum.javaadv.printer;

public record Completed(int numberOfPages) implements PrintResult {

}
