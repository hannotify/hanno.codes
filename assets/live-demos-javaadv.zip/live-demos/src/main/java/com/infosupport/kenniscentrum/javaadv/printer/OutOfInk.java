package com.infosupport.kenniscentrum.javaadv.printer;

public record OutOfInk(String color) implements PrintResult {

}
