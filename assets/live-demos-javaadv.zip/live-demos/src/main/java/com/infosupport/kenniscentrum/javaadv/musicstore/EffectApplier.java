package com.infosupport.kenniscentrum.javaadv.musicstore;

public class EffectApplier {
    static void apply(Effect effect) {
        switch (effect) {
            case Effect.Reverb(int roomSize):
                var reverbDescription = switch (roomSize) {
                    case 1 -> "Toilet";
                    case 2 -> "Bedroom";
                    case int i when i > 5 && i < 25 -> "Small classroom";
                    case 30 -> "Big Classroom";
                    case int i when i > 100 && i <= 600 -> "Cinema";
                    case int i when i > 500 && i <= 1000 -> "Cathedral";
                    case int i when i > 10000 -> "Stadium";
                    case int i -> "Unknown room size";
                };
                System.out.println(reverbDescription);
                break;
            case Effect.Delay(int timeInMs):
                System.out.println(timeInMs);
                break;
            case Effect.Distortion distortion:
                break;
            case null:
                throw new NullPointerException("Effect is null");
            default:
                throw new IllegalArgumentException("Unknown effect");
        }
    }
}
