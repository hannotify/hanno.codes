package com.infosupport.kenniscentrum.javaadv.printer;

import java.io.IOException;

public class Printer {
    private String model;
    private int paperCapacity;

    public Printer(String model) {
        this(model, 0);
    }

    public Printer(String model, int paperCapacity) {
        this.model = model;
        this.paperCapacity = paperCapacity;
    }


    public PrintResult print(int numberOfPages) throws IOException {
        if (paperCapacity - numberOfPages < 0) {
            return new OutOfPaper();
        }

        return new Completed(numberOfPages);
    }
}
