package com.infosupport.kenniscentrum.javaadv.musicstore;

public sealed interface Effect {
    void apply();

    record Delay(int timeInMs) implements Effect {
        public Delay {
            if (timeInMs < 0) {
                throw new IllegalArgumentException("Time in ms must be positive");
            }
        }

        Delay(int timeInMs, String message) {
            this(timeInMs);

            System.out.println(message);
        }

        @Override
        public void apply() {
            System.out.println("Applying Delay");
        }
    }

    record Reverb(int roomSize) implements Effect {
        @Override
        public void apply() {
            System.out.println("Applying Reverb");
        }
    }

    record Distortion(String name) implements Effect {
        @Override
        public void apply() {
            System.out.println("Applying Distortion");
        }
    }
}

non-sealed interface Tuner extends Effect {
    void tune();
}
