package com.infosupport.kenniscentrum.javaadv;

/**
 * The {@code String} class represents character strings. All
 * string literals in Java programs, such as {@code "abc"}, are
 * implemented as instances of this class.
        * <p>
 * Strings are constant; their values cannot be changed after they
 * are created. String buffers support mutable strings.
 * Because String objects are immutable they can be shared. For example:
        * <blockquote><pre>
 *     String str = "abc";
 * </pre></blockquote><p>
 * is equivalent to:
 * {@snippet :
 *     // @highlight region="italic-region" type="italic"
 *     char data[] = {'a', 'b', 'c'};
 *     List<String> list = new ArrayList<>();
 *     String str = new String(data);
 *     // @link substring="length()" target="String#length" type="link" :
 *     str.length();
 *     // @end region="italic-region"
 * }
 * {@snippet file="ExternalSnippet.java"}
 */
public class MyString {
}
