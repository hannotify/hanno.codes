class ExternalSnippet {
    public void doSomething() {
        System.out.println("Hello, world!");
    }
}