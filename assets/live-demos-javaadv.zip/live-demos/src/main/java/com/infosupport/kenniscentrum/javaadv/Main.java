package com.infosupport.kenniscentrum.javaadv;

public class Main {
    public static void main(String[] args) {
//        var user = readln("Type your name plz: ");
//        println("Hello, %s".formatted(user));
    }
}
